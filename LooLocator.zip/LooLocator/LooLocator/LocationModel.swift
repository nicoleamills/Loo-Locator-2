//
//  LocationModel.swift
//  LooLocator
//
//  Created by Tech on 27/04/2023.
//

import Foundation
import SwiftyJSON

class LocationModel{
    
    var placeName : String = ""
    var user_ratings_total : Int = 0
    var vicinity : String = ""
    var rating : Double = 0.0
    var compound_code : String = ""
    var types : [String] = [String]()
    
    init(json : JSON){
        self.placeName = json["name"].stringValue
        self.user_ratings_total = json["user_ratings_total"].intValue
        self.vicinity = json["vicinity"].stringValue
        self.rating = json["rating"].doubleValue
        self.compound_code = json["plus_code"]["compound_code"].stringValue
        for each in json["types"].arrayValue{
            self.types.append(each.stringValue)
        }
    }
}
