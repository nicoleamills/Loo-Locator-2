//
//  UserLocationViewController.swift
//  
//
//  Created by Rana Taimoor on 4/26/23.
import UIKit
import GooglePlaces
import CoreLocation
import SwiftyJSON


protocol AddressViewDelegateProtocol {
    func selectedAddress(AddressData: GMSAutocompletePrediction)
}

class UserLocationViewController: UIViewController, CLLocationManagerDelegate , RatingViewControllerDelegate{
   

    @IBOutlet weak var addressTableView: UITableView!
    @IBOutlet weak var txtAddress: UITextField!
    var delegate: AddressViewDelegateProtocol? = nil
    var locationManager: CLLocationManager!
    var lattitude = 0.0
    var longitude = 0.0
    var locationList = [LocationModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtAddress.delegate =  self
        self.detectLocation()
    }
    
    func getNearbyToilet(lat : Double , lng : Double , placeName : String){
        let url = URL(string: "https://maps.googleapis.com/maps/api/place/nearbysearch/json?key=AIzaSyA8qJf45bcY03gqb8dkYg4uIGH0MROy6e8&location=\(lat),\(lng)&radius=5000&name=\(placeName)")!
        let task = URLSession.shared.dataTask(with: url) {(data, response, error) in
            guard let data = data else { return }
            let json = JSON(parseJSON: String(data: data, encoding: .utf8)!)
            print(json)
            self.locationList.removeAll()
            DispatchQueue.main.async {
                self.addressTableView.reloadData()
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                for each in json["results"].arrayValue{
                    self.locationList.append(LocationModel(json: each))
                }
                self.addressTableView.reloadData()
            }
        }
        task.resume()
    }
    

    func detectLocation() {
        locationManager = CLLocationManager()
        locationManager.distanceFilter = 200
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        if locationManager.authorizationStatus == .notDetermined {
            locationManager.requestAlwaysAuthorization()
        }else if locationManager.authorizationStatus == .authorizedAlways || locationManager.authorizationStatus == .authorizedWhenInUse {
            locationManager.startUpdatingLocation()
        }else if locationManager.authorizationStatus == .denied{
           print("Access to location denied")
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let userLocation = locations[0] as CLLocation
        lattitude = userLocation.coordinate.latitude
        longitude = userLocation.coordinate.longitude
        self.locationManager.stopUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) -> Void{
        switch status{
        case .authorizedAlways, .authorizedWhenInUse:
            locationManager.startUpdatingLocation()
        case .denied:
           print("Denied")
        default:
            print("Unknown")
        }
    }
    func didTappedSearch() {
        self.txtAddress.becomeFirstResponder()
    }
    
}
extension UserLocationViewController:UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.locationList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserLocationTableViewCell", for: indexPath) as! UserLocationTableViewCell
        cell.lblLocationNum.text = "Location #\(indexPath.item + 1)"
        cell.confiqureView(addressType: "\(locationList[indexPath.row].placeName) \(locationList[indexPath.row].vicinity)")
        cell.selectionStyle = .none
        return cell
    }
    func textFieldDidChangeSelection(_ textField: UITextField) {
        if textField.text != ""{
            self.getNearbyToilet(lat: self.lattitude, lng: self.longitude, placeName: self.txtAddress.text ?? "")
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 130
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "RatingViewController") as! RatingViewController
        vc.index = indexPath.row + 1
        vc.delegate = self
        vc.selectedLocation = self.locationList[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
