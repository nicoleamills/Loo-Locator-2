//
//  LoginViewController.swift
//  LooLocator
//
//  Created by Rana Taimoor on 4/26/23.
//

import UIKit
import Firebase
import FirebaseAuth
class LoginViewController: UIViewController {
    
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtpassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    // Mark: Functions
    
    private func NewUser(){
        Auth.auth().createUser(withEmail: txtEmail.text!, password:txtpassword.text!) { user, error in
            if error != nil{
                print(error?.localizedDescription)
                self.AlertpopUp(message: "User already exists with this email")
                
            }
            else{
               // self.AlertpopUp(message: "Sign Up Succesfuully")
                
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                 let vc = storyBoard.instantiateViewController(withIdentifier: "UserLocationViewController") as! UserLocationViewController
                 self.navigationController?.pushViewController(vc, animated: true)
            }
            
            
        }
        
    }
    private func login(){
        Auth.auth().signIn(withEmail: txtEmail.text ?? "", password: txtpassword.text ?? "") { user, error in
            if error != nil{
                print(error?.localizedDescription)
                self.AlertpopUp(message: "User does not exists please try again")
            }
            
            else if user != nil{
                
                print("Login Sucessfylly")
                //self.AlertpopUp(message: "Login Sucessfylly")
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                 let vc = storyBoard.instantiateViewController(withIdentifier: "UserLocationViewController") as! UserLocationViewController
                 self.navigationController?.pushViewController(vc, animated: true)
            }
            else{
                print("user does not exsit")
                self.AlertpopUp(message: "User does not exists please try again")
            }
            
        }
    }
    
    func AlertpopUp(message:String){
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    

   
    @IBAction func actionLogin(_ sender: Any) {
        if(txtpassword.text?.count ?? 0 >= 6){
           self.login()
        }else{
            self.AlertpopUp(message: "Please enter atleast 6 character")
        }
        
    }
    @IBAction func actionSignUp(_ sender: Any) {
       
        if(txtpassword.text?.count ?? 0 >= 6){
           self.NewUser()
        }else{
            self.AlertpopUp(message: "Please enter atleast 6 character")
        }
    }
    
}
