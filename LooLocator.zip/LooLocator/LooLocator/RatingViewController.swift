//
//  RatingViewController.swift
//  LooLocator
//
//  Created by Tech on 27/04/2023.
//

import UIKit
protocol RatingViewControllerDelegate : AnyObject{
    func didTappedSearch()
}

class RatingViewController: UIViewController {

    var selectedLocation : LocationModel!
    @IBOutlet weak var lblDetails: UILabel!
    @IBOutlet weak var lblLocationNUm: UILabel!
    @IBOutlet weak var lblRating: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    var index = 0
    weak var delegate : RatingViewControllerDelegate?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.configureView()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func actionBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
  
    @IBAction func actionSearch(_ sender: Any) {
        delegate?.didTappedSearch()
        self.navigationController?.popViewController(animated: false)
    }
   
    func configureView(){
        self.lblLocationNUm.text = "Location #\(index)"
        self.lblAddress.text = selectedLocation.vicinity
        self.lblRating.text = "Rating \(String(format: "%.0f" , selectedLocation.rating))/5"
        self.lblDetails.text = "Name of location is \(selectedLocation.placeName)\nTotal ratings added by people are \(selectedLocation.user_ratings_total)\nComplete address of location is \(selectedLocation.compound_code)"
    }
    
}
