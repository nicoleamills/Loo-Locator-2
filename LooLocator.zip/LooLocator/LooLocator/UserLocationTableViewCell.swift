//
//  UserLocationTableViewCell.swift
//  LooLocator
//
//  Created by Rana Taimoor on 4/26/23.
//

import UIKit

class UserLocationTableViewCell: UITableViewCell {

    @IBOutlet weak var lblLocationNum: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    func confiqureView(addressType: String) {
        
        self.lblAddress.text = addressType
        
        
    }


}
