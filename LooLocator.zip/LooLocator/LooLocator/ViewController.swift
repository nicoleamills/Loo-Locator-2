//
//  ViewController.swift
//  LooLocator
//
//  Created by Rana Taimoor on 4/26/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

